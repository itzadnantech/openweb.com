$(document).ready(function() {
   var links = [
       {label: 'Account Settings', category: '/user/settings'},
       {label: 'Billing Settings', category: '/user/settings'},
       {label: 'Avios Settings', category: '/user/settings'},
       {label: 'Personal Data', category: '/user/settings'},
       {label: 'Change Password', category: '/user/settings'},
       {label: 'Mailing List', category: '/user/settings'},
       {label: 'Invoice email', category: '/user/settings'},
       {label: 'Active Services', category: '/user/active_orders'},
       {label: 'Inactive Services', category: '/user/inactive_orders'},
       {label: 'All Services', category: '/user/orders'},
       {label: 'Activity Log', category: '/user/activity_log'},
       {label: 'Invoices', category: '/user/invoices'}
       ];


});