<?php
//related to virtual awards inside the system
class Avios_virtual extends CI_Model 
{

	


}