<div id="page-content" class="container">
  	<div class="row">
  		 <div class="col-lg-8">
  		 	<div class="alert alert-danger">The product does not exist </div>
  		 </div>
  	</div>
</div>