<div id="page-content" class="container">
	<div class="lead">
	<?php if(isset($message) && !empty($message)){
		echo $message;
	}?>
	</div>
</div>

<?php
    if (isset($conversion_flag) && ($conversion_flag == true)){

?>
        <!-- Google Code for OpenWeb SIgnup Conversion Page -->
        <script type="text/javascript">
            /* <![CDATA[ */
            var google_conversion_id = 1071738246;
            var google_conversion_language = "en";
            var google_conversion_format = "3";
            var google_conversion_color = "ffffff";
            var google_conversion_label = "PlEuCOKO0QEQhtuF_wM";
            var google_conversion_value = 1.00;
            var google_conversion_currency = "USD";
            var google_remarketing_only = false;
            /* ]]> */
        </script>
        <script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
        </script>
        <noscript>
            <div style="display:inline;">
                <img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/1071738246/?value=1.00&amp;currency_code=USD&amp;label=PlEuCOKO0QEQhtuF_wM&amp;guid=ON&amp;script=0"/>
            </div>
        </noscript>
        <!-- Facebook Conversion Code for OpenWeb Completed Sales -->
        <!-- Facebook Pixel Code -->
        <script>
            !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
                n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
                n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
                t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
                document,'script','https://connect.facebook.net/en_US/fbevents.js');

            fbq('init', '1415741678699152');
            fbq('track', "PageView");</script>
        <noscript><img height="1" width="1" style="display:none"
                       src="https://www.facebook.com/tr?id=1415741678699152&ev=PageView&noscript=1"
                /></noscript>
        <!-- End Facebook Pixel Code -->

        <!-- Facebook Pixel Code #2 -->
        <script>
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
                n.callMethod.apply(n,arguments):n.queue.push(arguments)};
                if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
                n.queue=[];t=b.createElement(e);t.async=!0;
                t.src=v;s=b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t,s)}(window,document,'script',
                'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '523215891205683');
            fbq('track', 'PageView');
        </script>
        <noscript>
            <img height="1" width="1"
                 src="https://www.facebook.com/tr?id=523215891205683&ev=PageView
&noscript=1"/>
        </noscript>
        <!-- End Facebook Pixel Code -->

<?php
      }
?>