<?php
$this->load->view($main_content);
?>