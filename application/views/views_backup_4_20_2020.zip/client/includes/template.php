<?php	
	$this->load->view("client/includes/header", $sidebar);
	$this->load->view($main_content);	
	$this->load->view("client/includes/footer");
?>
