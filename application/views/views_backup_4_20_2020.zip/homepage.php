<?php

	$this->load->view('includes/template');

?>