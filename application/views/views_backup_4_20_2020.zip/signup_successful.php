<h1>The user account has been created successfully.</h1>
