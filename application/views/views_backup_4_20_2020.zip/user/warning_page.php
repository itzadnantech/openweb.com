<div class="well">
	<div class="lead">Notices</div>
	<h4 style="margin-bottom:20px">
		 If you want to modify the service, please send email to <font style="color: #428bca">admin@openweb.co.za</font>.
	</h4>
</div>
