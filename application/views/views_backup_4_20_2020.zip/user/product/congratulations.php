<div class="page-content">
<div class="clearfix"></div>
<div class="content">
    <div class="page-title">
    </div>
<div class="lead">
	<?php
    if(isset($message) && !empty($message)){
		echo "<h3>".$message."</h3>";
	}
    if ( isset($return_to_active_orders) && ($return_to_active_orders == true) ){

        echo "<br/><br/><a class='btn btn-default' href='" . $back_url . "' >Back to Active Services</a>";
    }

    ?>
</div>
</div>
</div>
</div>
<!-- Google Code for OpenWeb SIgnup Conversion Page -->
<script type="text/javascript">
    /* <![CDATA[ */
    var google_conversion_id = 1071738246;
    var google_conversion_language = "en";
    var google_conversion_format = "3";
    var google_conversion_color = "ffffff";
    var google_conversion_label = "PlEuCOKO0QEQhtuF_wM";
    var google_conversion_value = 1.00;
    var google_conversion_currency = "USD";
    var google_remarketing_only = false;
    /* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
    <div style="display:inline;">
        <img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/1071738246/?value=1.00&amp;currency_code=USD&amp;label=PlEuCOKO0QEQhtuF_wM&amp;guid=ON&amp;script=0"/>
    </div>
</noscript>



<!-- BING -->
<script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"5012809"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script><noscript><img src="//bat.bing.com/action/0?ti=5012809&Ver=2" height="0" width="0" style="display:none; visibility: hidden;" /></noscript>