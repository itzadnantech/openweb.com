<div class="page-content">
    <!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
    <div class="clearfix"></div>
    <div class="content">
        <div class="page-title">
            <h3 class="col-md-offset-2">Order Result</h3>
        </div>
        <div class="row">
            <div class="col-md-offset-2 col-md-8">
                <div class="grid simple">
                    <?php echo $message ?>
                </div>
            </div>
        </div>
    </div>
</div>