<?php
$name = $product_data['name'];
echo "<h2>$name</h2>";	