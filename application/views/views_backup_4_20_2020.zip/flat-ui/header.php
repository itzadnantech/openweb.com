
<head>
    <meta http-equiv="Content-Type" content="&lt;/head">

    <title>OpenWeb Home's Panel</title>
    <script src="<?php echo base_url('js/jquery.min.js'); ?>"></script>

    <link href="<?php echo base_url('css/jquery-ui.css'); ?>" rel="stylesheet">

    <script src="<?php echo base_url('js/jquery-ui.js'); ?>"></script>
    <script src="<?php echo base_url('js/jquery.validate.js'); ?>"></script>
    <script src="<?php echo base_url('js/Highcharts/highcharts.js'); ?>"></script>
    <script src="<?php echo base_url('js/Highcharts/modules/exporting.js'); ?>"></script>

    <link href="<?php echo base_url('css/bootstrap3/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('css/bootstrap3/bootstrap-glyphicons.css'); ?>" rel="stylesheet">
    <script src="<?php echo base_url('js/bootstrap3/bootstrap.min.js'); ?>"></script>
    <link rel="stylesheet" href="<?php echo base_url('css/style.css'); ?>" type="text/css" media="screen" charset="utf-8">
    <link rel="icon" href="<?php echo base_url()?>img/favicon.gif" type="image/gif">

    
    <link href="<?php echo base_url('css/flat-ui/flat-global-style.css'); ?>" rel="stylesheet">

    
    <style type="text/css">
        .error{
            color: #f62b2b;
        }
    </style>
</head>

