</div>
</div>
</div>
<div class="footer col-lg-12">
    <div class="container footer-inner">
        <p class="copyright">Copyright &copy; OpenWeb. All rights reserved.</p>
        <ul class="footerNav">
            <li><a target="_new" href="<?php echo TERMS_OF_SERVICE_LINK; ?>">Privacy policy</a></li>
            <li><a target="_new" href="<?php echo SUPPORT_LINK; ?>">Contact us</a></li>
        </ul>
    </div>
</div>
</body>
</html>