<?php

    echo "all showmax subscriptions";