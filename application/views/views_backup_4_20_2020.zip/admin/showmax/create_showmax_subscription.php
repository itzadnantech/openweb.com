<?php

    echo "";
?>

<h3>Assign ShowMax subscription</h3><br><br>


<?php

//$topup_data['edit_flag'] = false;
$this->load->view("admin/showmax/showmax_subscription_form", $data["user_list"] = $user_list);

?>
