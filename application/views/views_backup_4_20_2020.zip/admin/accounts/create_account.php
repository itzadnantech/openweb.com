<h3>Create Account</h3>

<?php

$user_data['edit_user'] = '';
$this->load->view('admin/accounts/account_form', $user_data);

?>