<script language="javascript" type="text/javascript">
$(function(){
    $( "#date" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      changeYear: true,
      dateFormat: 'yy-mm-dd',
    });
});
</script>
<?php 
if(isset($user_id)){
	$account_id = $user_id;
}
?>
<div class="container" style="margin: 20px 0 30px 0;">
	<fieldset>								
		<div class="col-lg-2">
			<?php echo anchor('admin/all_account', 'User List', array('class' => 'form-control btn btn-default')); ?>
		</div>
		<div class="col-lg-2">
			<?php echo anchor('admin/user_service/'.$account_id, 'Service List', array('class' => 'form-control btn btn-default')); ?>
		</div>
		<div class="col-lg-2">
			<?php echo anchor('admin/create_account', 'Create New', array('class' => 'form-control btn btn-default')); ?>
		</div>
	</fieldset>
</div>
<h3>Edit Order</h3>
<?php
if (isset($messages['success_message']) && trim($messages['success_message']) != '') {
	?>
	<div class="alert alert-success">
		<?php echo $messages['success_message'] ?>
	</div>
	<?php
}
?>

<?php

if ($order_id && trim($order_id) != '') {
	echo form_open('admin/edit_lte_order/'.$order_id, array('class' => 'form-horizontal','id' => 'manage_order_form'));
	?>
	<input type="hidden" name="id" value="<?php echo $order_id ?>" />
	<?php

	foreach ($order_data as $title => $value) {
	    if($title == 'Percentage' || $title == 'Total Data') {
            if(!$show_percentage) {
                continue;
            }
        }
		?>
            <div class="form-group">
                <label class="control-label col-lg-3">
                    <?php echo $title; ?>
                </label>
                <div class="col-lg-7">

                <?php
                if ($title == 'Status') {
                    $statuses = array ('active', 'pending', 'deleted', 'suspended', 'expired', 'pending cancellation');
                    $status_list = array();

                    foreach ($statuses as $s) {
                        $status_list[$s] = ucfirst($s);
                    }

                    echo form_dropdown('status', $status_list, $value, 'class="form-control disabled"');
                } elseif($title == 'Billling Cycle') {
                    $cycles = array ('Monthly', 'Once-Off');
                    $cycle_list = array();

                    foreach ($cycles as $cycle) {
                        $cycle_list[$cycle] = ucfirst($cycle);
                    }

                    echo form_dropdown('cycle', $cycle_list, $value, 'class="form-control disabled"');
                } elseif($title == 'Percentage') { ?>
                    <div class="input-group">
                        <input type="text" name="<?php echo strtolower(str_replace(' ', '_', $title)) ?>" class="form-control" value="<?php echo $value; ?>">
                        <div class="input-group-addon"> % </div>
                    </div>
                <?php
                } elseif($title == 'Total Data') { ?>
                    <div class="input-group">
                        <input type="text" name="<?php echo strtolower(str_replace(' ', '_', $title)) ?>" class="form-control" value="<?php echo $value; ?>">
                        <div class="input-group-addon">GB</div>
                    </div>
                    <?php
                }
	                 elseif($title == 'Username') {
	                 $name =strstr($value, '@',true);
	                 if(empty($name)){
	                     $name = $value;
	                 }
	                 ?>
                 
                        <input type="text" name="<?php echo strtolower(str_replace(' ', '_', $title)) ?>" class="form-control" value="<?php echo $name; ?>">
                 
                    <?php
                }  elseif($title == 'Realm') {
                    $relm = ltrim($value, '@');
                   
	                 ?>
                            
                        <input type="text" name="<?php echo strtolower(str_replace(' ', '_', $title)) ?>" class="form-control" value="<?php echo $relm; ?>">
                 
                    <?php
                }
                else {
                ?>
                    <input type="text" name="<?php echo strtolower(str_replace(' ', '_', $title)) ?>" class="form-control" value="<?php echo $value; ?>">

                <?php
                }
                ?>
                </div>
			</div>
<?php
    }
?>
	
	<div style="text-align:center">
		<input type="submit" class="btn btn-large btn-success" value="Update Order" />
	</div>

<?php form_close();

} else {
	?>
	<div class="alert alert-warning">
		<strong>Order not found.</strong> It seems that there is no order with that ID!
	</div>
<?php
}
?>