<h3>Create a New Category</h3>

<?php

$category_data['edit_category'] = '';
$this->load->view('admin/categories/category_form', $category_data);

?>