<h3>Edit TopUp configuration</h3><br><br>


<?php

$topup_data['edit_flag'] = true;
$this->load->view('admin/topups/topup_conf_form', $topup_data);

?>