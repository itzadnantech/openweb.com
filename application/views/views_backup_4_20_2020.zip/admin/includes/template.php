
<?php
$this->load->view("admin/includes/header", $sidebar);

$this->load->view($main_content, $data);
$this->load->view("admin/includes/footer");

?>
