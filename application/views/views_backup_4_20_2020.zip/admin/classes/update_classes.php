<h3>Update Classes Request</h3>

<div class="lead">
Updating your classes will delete all of your current classes and replace them with what we get from searching IS for classes. Are you sure you want to do this?
</div>
<?php
echo anchor('admin/update_classes/confirm', 'Yes, Update Classes.', 'class="btn btn-default btn-lg"');