<h3>Create a New Sub-Category</h3>

<?php

$subcategory_data['edit_subcategory'] = '';
$this->load->view('admin/subcategories/category_form', $subcategory_data);

?>