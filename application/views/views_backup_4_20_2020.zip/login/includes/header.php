<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="&lt;/head">

    <title>KeomaWeb</title>
	<link rel="stylesheet" href="<?php echo base_url('css/style.css'); ?>" type="text/css" media="screen" charset="utf-8">
	<script src="<?php echo base_url('js/jquery.min.js'); ?>"></script>
	<link href="<?php echo base_url('css/bootstrap.min.css'); ?>" rel="stylesheet">
	<script src="<?php echo base_url('js/bootstrap.min.js'); ?>"></script>
	
</head>
<body>
<div class="hero-unit">
	<h2>Login <small></small></h2>
</div>
<div class="container-fluid">
  <div class="row-fluid">
    <div class="span3">
      
    </div>
    <div class="span9">
      <!--Body content-->
      