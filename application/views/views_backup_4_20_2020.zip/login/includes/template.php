<?php

	$this->load->view("login/includes/header");
	$this->load->view($main_content);
	
	$this->load->view("login/includes/footer");

?>