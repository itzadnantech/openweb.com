<body class="error-body no-top" style="background-color: #fff">
<div class="container">
    <div class="row login-container">
        <div class="col-md-4 col-md-offset-4">
            <a href="<?php echo base_url() ?>"><img class="img-responsive" src="<?php echo base_url('/img/main.png') ?>"></a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 col-md-offset-4 text-center">
            <div class="logout-message">
                <p>You have been successfully logged out.</p>
            </div>
            <div>
                <p><a href="<?php echo base_url() ?>"><button type="button" class="btn btn-success btn-cons">Login</button></a></p>
            </div>
        </div>
    </div>
</div>